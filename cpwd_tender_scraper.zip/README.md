# CPWD Tender Scraper

This Python script scrapes tender data from the CPWD e-Tender website (https://etender.cpwd.gov.in/).

## Features

- Navigates to the "New Tenders" tab and selects the "All" sub-tab
- Extracts details for the first 20 tenders listed
- Saves the data to a CSV file with renamed columns

## Fields Extracted

The script extracts the following fields:
1. NIT/RFP NO (saved as "ref_no")
2. Name of Work / Subwork / Packages (saved as "title")
3. Estimated Cost (saved as "tender_value")
4. Bid Submission Closing Date & Time (saved as "bid_submission_end_date")
5. EMD Amount (saved as "emd")
6. Bid Opening Date & Time (saved as "bid_open_date")

## Installation

1. Install Python 3.8 or higher
2. Install the required packages:
   ```
   pip install -r requirements.txt
   ```

## Usage

Run the script with:
```
python cpwd_scraper.py
```

The script will:
1. Open a headless Chrome browser
2. Navigate to the CPWD website
3. Extract data from the first 20 tenders
4. Save the data to a CSV file named "cpwd_tenders.csv"

## Notes

- The script uses Selenium with Chrome in headless mode
- You need to have Chrome browser installed on your system
- The webdriver-manager package will automatically download the appropriate ChromeDriver version